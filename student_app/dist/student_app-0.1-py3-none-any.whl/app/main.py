def greet (name: str) -> str:
    return f"Hello, {name}! Welcome to Packagigng Lab."

if __name__ == "__main__":
    print(greet("Student"))